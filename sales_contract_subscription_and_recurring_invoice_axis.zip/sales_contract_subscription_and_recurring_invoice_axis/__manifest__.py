
# -*- coding: utf-8 -*-
{
    'name': 'Sales Contract Subscription and Recurring Invoice in odoo, Sales Contract Subscription in odoo and Recurring Invoice in odoo, Subscription management in odoo',
    'version': '15.0.0.1',
    'category': 'Website',
    'summary': """Sales Contract Subscription management in odoo, 
                Sales Contract Subscription in odoo and Recurring Invoice in odoo,
                product subscription, invoice management sale contract subscription contract management, create bulk invoice, customer invoice 
                management  sales order subscription Recurring customer subscription invoice subscription""",
    'description': """Sales Contract Subscription management in odoo, 
                Sales Contract Subscription in odoo and Recurring Invoice in odoo, 
                Dashboard for manage product for product subscription, invoice management and 
                sale contract, contract management, create bulk invoice, customer invoice management """,
    'depends': [
        'product',
        'sale',
        'sale_management',
        'account',
        'analytic'
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/mail_data.xml',
        # 'data/data.xml',
        'views/assets.xml',
        'views/product_template_view.xml',
        'views/sale_order_view.xml',
        'views/menu_dashboard.xml',
        'views/analytic_account_view.xml',
        'views/report.xml',
        'report/contract_report.xml',
        'wizard/invoice_contract.xml',
    ],
    'qweb': ["static/src/xml/dashboard.xml"],
    'price': 85.00,
    'currency': 'USD',
    'license': 'AGPL-3',
    'support': 'business@axistechnolabs.com',
    'author': 'Axis Technolabs',
    'website': 'https://www.axistechnolabs.com',
    'application': True,
    'installable': True,
    'auto_install': False,
    'images': ['static/description/images/banner.jpg'],
    'assets': {
        'website.assets_editor':[
            'sales_contract_subscription_and_recurring_invoice_axis/static/src/js/dashboard.js',
            'sales_contract_subscription_and_recurring_invoice_axis/static/src/js/Chart.js',
            'sales_contract_subscription_and_recurring_invoice_axis/static/src/css/nv.d3.css',
        ],
    },

}
