
# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.tools.float_utils import float_compare
from datetime import datetime
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError

from odoo.addons.purchase.models.purchase import PurchaseOrder as Purchase
import logging
_logger = logging.getLogger(__name__)


class PoRevisonLog(models.Model):
    _name = 'po.revison.log'

    order_id = fields.Many2one('purchase.order')
    order_line_id = fields.Many2one('purchase.order.line')   
    product_qty = fields.Float('Product Qty') 
    price_unit = fields.Float('Unit Price')  


