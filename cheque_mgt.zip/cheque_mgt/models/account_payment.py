# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
import logging
import requests
import json
import datetime
_logger = logging.getLogger(__name__)

class AccountPayment(models.Model):
    _inherit = 'account.payment'

    cheque_book = fields.Many2one('cheque.books','Select ChequeBook')
    cheques_id= fields.Many2one('cheques',"Select Cheque")
    effective_date = fields.Date("effectivee Date")
    def action_post(self):
        super(AccountPayment, self).action_post()
        self.cheques_id.write({'cheque_status':'issued'})


       
    # @api.onchange('cheque_book')
    # def _onchange_cheque_book(self): 
    #      if self.dentist_id:
    #           self.dentist_id=False  
    #      if self.service_type:
    #           self.service_type=False                
    #      if self.service_location:
    #             partner_obj = self.env['res.partner']
    #             appointment_obj = self.env['appointments']
    #             doctor_obj = self.env['doctor']
    #             doctor_service_type_obj = self.env['doctor.service.type']
    #             appointment_availablity_obj = self.env["appointment.availablity"]
    #             appointment_time_obj=self.env["appointment.time"]
    #             service_location_obj=self.env["service.location"]
    #             partner_model_obj=self.env["patient"]
    #             line_list=[]

    #             location_ids=appointment_availablity_obj.sudo().search([('availablity_location_id','=', self.service_location.id)])
    #             print('location_ids-post---%s' % location_ids)

    #             for location_id in location_ids:
    #                 doctor_id=location_id.availablity_id.id
    #                 doctor_data=doctor_obj.sudo().browse(doctor_id)
    #                 if doctor_data.sub_service_ids:
    #                     for service_id in doctor_data.service_ids:
                            
    #                         line_list.append(service_id.id)
    #             print('line_list-post---%s' % line_list)
    #             return {'domain':{'service_type': [('id', 'in', line_list)]}} 
    #      else:
    #             return False 
 
   