
# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.tools.float_utils import float_compare
from datetime import datetime
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError
from odoo.exceptions import UserError

import logging
_logger = logging.getLogger(__name__)


class AccountJournal(models.Model):
    _inherit = 'account.journal'


    alloated_chquebook_ids = fields.One2many('cheque.books', 'cheque_id', string='Cheque Books')



class ChequeBooks(models.Model):
    _name = 'cheque.books'

    name = fields.Char("Name")
    from_no = fields.Integer("From Cheque Number")
    to_no = fields.Integer("From To Number")
    issued_date = fields.Date("Issued Date")
    cheque_id = fields.Many2one('account.journal',"Cheque Id")
    alloated_chequeno = fields.One2many('cheques', 'cheque_book_id', string='Cheque Nos')

    def name_get(self):
        result = []
        for rec in self:
                name = '%s[%s - %s]' % (rec.issued_date,rec.from_no, rec.to_no)
                result.append((rec.id, name))
        return result


    def generate_cheques(self):
        cheques_obj=self.env['cheques']
        if self.from_no >= self.to_no:
            raise UserError(_("Cheque From No must be less than chque To No"))


        from_no =self.from_no
        to_no =self.to_no

        while int(from_no) <= int(to_no):

            cheques_obj.create({'cheque_no':from_no,'cheque_book_id':self.id})
            from_no+=1



        
        return 


class Cheques(models.Model):
    _name = 'cheques'

    cheque_no = fields.Integer("Cheque Number")
    issued_date = fields.Date("Issued Date")
    cheque_status = fields.Selection(string='Cheque Status', selection=[('not_issued', 'Not Issued'),('issued', 'Issued')], default='not_issued')
    cheque_book_id = fields.Many2one('cheque.books',"Cheque Book Id")

    def name_get(self):
        result = []
        for rec in self:
                name = '%s' % (rec.cheque_no)
                result.append((rec.id, name))
        return result


  