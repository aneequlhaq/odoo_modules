# -*- coding: utf-8 -*-
{
    'name': "Qtech Cheque  Management",

    'summary': """Qtech Chque Management""",

    'description': """Qtech Chque Management""",

    'author': "qtech solutions",
    'website': "",

    'category': 'Uncategorized',
    'version': '1.0',

    'depends': ['product','stock','purchase','purchase_stock','account'],

    'data': [
        "security/ir.model.access.csv",
        # 'views/product_template.xml',
        # 'views/purchase_order.xml',
        'views/account_journal_view.xml',
        'views/account_payment.xml'
   
    ],
}

