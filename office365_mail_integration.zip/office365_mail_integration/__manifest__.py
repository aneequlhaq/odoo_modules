# -*- coding: utf-8 -*-
{
    'name': "Office365 Auth Submit",
    'summary': """Office365 Auth Submit""",
    'description': """Office365 Auth Submit""",
    'author': "EXP-SA",
    'depends': ['base','mail'],
    'data': [
    ],

}
