{
    "name": "POS QR Code",
    "version": "15.0.1.0.0",
    "author": "Odoo PS",
    "website": "https://www.odoo.com",
    "license": "OEEL-1",
    "depends": [
        "point_of_sale",
    ],
    "data": [
        "views/pos_config.xml",
    ],
    "assets": {
        "point_of_sale.assets": [
            "pos_qr_code/static/src/**/*.js",
            "pos_qr_code/static/src/**/*.css",
        ],
        "web.assets_qweb": ["pos_qr_code/static/src/**/*.xml"],
    },
}
