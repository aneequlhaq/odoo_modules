from odoo import fields, models


class PosConfig(models.Model):
    _inherit = "pos.config"

    qr_code = fields.Char()
