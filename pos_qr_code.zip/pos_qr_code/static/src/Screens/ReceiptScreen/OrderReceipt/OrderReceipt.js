/** @odoo-module */
import OrderReceipt from "point_of_sale.OrderReceipt";
import Registries from "point_of_sale.Registries";
import { loadAssets } from "@web/core/assets";


const OrderReceiptMixin = (OrderReceiptParent) =>
    class extends OrderReceiptParent {
        async willStart() {
            await loadAssets({
                jsLibs: ["/web_enterprise/static/lib/zxing-library/zxing-library.js"],
            });
            const codeWriter = new window.ZXing.BrowserQRCodeSvgWriter();
            const qr_code_svg = new XMLSerializer().serializeToString(
                codeWriter.write(this.env.pos.config.qr_code, 150, 150)
            );
            this.qr_code = "data:image/svg+xml;base64," + window.btoa(qr_code_svg);
            return await super.willStart(...arguments);
        }
    };

Registries.Component.extend(OrderReceipt, OrderReceiptMixin);

export default OrderReceipt;
