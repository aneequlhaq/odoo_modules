# Ps-Tech module : POS QR Code

Add QR Code for POS Session
