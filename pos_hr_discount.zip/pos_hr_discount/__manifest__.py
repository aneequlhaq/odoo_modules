{
    "name": "PoS Discount Limit",
    "summary": """Set discount limit on employees and enable on-spot permissions for discounts""",
    "author": "Odoo PS",
    "website": "https://www.odoo.com",
    "category": "Sales/Point Of Sale",
    "version": "15.0.1.0.0",
    "depends": ["base", "pos_hr", "pos_discount"],
    "data": [
        "security/ir.model.access.csv",
        "data/hr.employee.role.csv",
        "views/product_views.xml",
        "views/hr_employee_views.xml",
    ],
    "assets": {
        "point_of_sale.assets": [
            "pos_hr_discount/static/src/**/*.scss",
            (
                "after",
                "pos_hr/static/src/js/models.js",
                "pos_hr_discount/static/src/**/*.js",
            ),
        ],
        "web.assets_qweb": ["pos_hr_discount/static/src/**/*.xml"],
    },
    "license": "OEEL-1",
}
