from . import hr_employee_base
from . import hr_employee_role
from . import product_template
