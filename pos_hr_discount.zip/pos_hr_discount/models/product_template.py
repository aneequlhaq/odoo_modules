from odoo import fields, models


class ProductTemplate(models.Model):
    _inherit = "product.template"

    is_pos_discount_applicable = fields.Boolean()
