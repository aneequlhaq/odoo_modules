from odoo import fields, models


class HrEmployeeRole(models.Model):
    _name = "hr.employee.role"
    _description = "Employee POS Role"

    name = fields.Char()
    can_set_global_discount = fields.Boolean()
    can_set_line_discount = fields.Boolean()
    employee_ids = fields.One2many("hr.employee", "employee_role_id")
    global_discount_limit = fields.Float()
    line_discount_limit = fields.Float()
    can_issue_refunds = fields.Boolean()
