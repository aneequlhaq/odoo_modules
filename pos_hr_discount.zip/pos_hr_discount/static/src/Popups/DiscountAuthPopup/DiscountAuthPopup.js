/** @odoo-module **/
/* globals Sha1*/

import AbstractAwaitablePopup from "point_of_sale.AbstractAwaitablePopup";
import Registries from "point_of_sale.Registries";

const {useState} = owl.hooks;

class DiscountAuthPopup extends AbstractAwaitablePopup {
    setup() {
        this.state = useState({
            employee: "",
            password: "",
        });
    }

    /**
     * @returns {Promise<{authorized: Boolean}>}
     */
    async getPayload() {
        const employee = this.env.pos.employee_by_id[this.state.employee];

        // Intentional "==". We want casting when needed
        //
        // There was a revision of odoo where pins where not
        // hashed. Therefore, we should check both the provided password,
        // and its hash
        const pinMatchesPasswordOrHash =
            employee.pin == this.state.password || employee.pin == Sha1.hash(this.state.password);

        return {
            authorized: pinMatchesPasswordOrHash,
            employee,
        };
    }

    get employees() {
        return _.values(this.env.pos.employee_by_id).filter((e) => e.employee_role_id);
    }
}

DiscountAuthPopup.template = "DiscountAuthPopup";

Registries.Component.add(DiscountAuthPopup);

export default DiscountAuthPopup;
