/** @odoo-module **/
import NumpadWidget from 'point_of_sale.NumpadWidget';
import Registries from 'point_of_sale.Registries';

const NumpadWidgetMixin = (NumpadWidgetOrigin) =>
    class extends NumpadWidgetOrigin {
        mounted() {
            super.mounted.apply(this, arguments);
            this.env.pos.on('change:selectedOrderline', this.render, this);
        }

        willUnmount() {
            this.env.pos.off('change:selectedOrderline', null, this);
        }

        get hasManualDiscount() {
            const cashier = this.env.pos.get_cashier();
            if (!cashier || !cashier.employee_role_id) return false;
            return (
                super.hasManualDiscount &&
                this.env.pos.employee_roles[cashier.employee_role_id[0]].can_set_line_discount &&
                this.env.pos.get_order().get_selected_orderline() &&
                this.env.pos.get_order().get_selected_orderline().get_product().is_pos_discount_applicable &&
                !this.env.pos.get_order().getGlobalDiscountLine()
            );
        }
    };

Registries.Component.extend(NumpadWidget, NumpadWidgetMixin);

export default NumpadWidget;
