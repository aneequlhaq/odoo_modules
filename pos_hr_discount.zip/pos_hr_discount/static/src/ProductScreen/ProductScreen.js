/** @odoo-module **/
import ProductScreen from 'point_of_sale.ProductScreen';
import Registries from 'point_of_sale.Registries';

const ProductScreenMixin = (ProductScreenOrigin) =>
    class extends ProductScreenOrigin {
        mounted() {
            super.mounted(...arguments);
            this.env.pos.on('change:discountValue', this.render, this);
            this.env.pos.on('change:selectedOrderline', this.render, this);
        }

        async _runValidations() {
            // to make this dev more reusable
            // if a client requires additional validations
            // simply add them here
            // [<string label>, <function that takes a cashier as an arg and returns a cashier>]
            const validations = [
                ['discountValid', this.currentOrder.validateDiscount.bind(this.currentOrder)],
                ['returnsValid', this.currentOrder.validateReturns.bind(this.currentOrder)],
            ];

            let previousValidationCashier = this.env.pos.get_cashier();
            for (const [label, validation] of validations) {
                previousValidationCashier = await validation(previousValidationCashier);
                if (!previousValidationCashier) return false;
            }

            return true;
        }

        async _onClickPay() {
            const proceed = await this._runValidations();
            if (proceed) return super._onClickPay(...arguments);
        }
    };

Registries.Component.extend(ProductScreen, ProductScreenMixin);

export default ProductScreen;
