/** @odoo-module **/
import models from 'point_of_sale.models';
import {Gui} from 'point_of_sale.Gui';

models.load_fields('product.product', ['is_pos_discount_applicable']);
models.load_fields('hr.employee', ['employee_role_id']);

models.load_models([
    {
        model: 'hr.employee.role',
        loaded: function (pos, roles) {
            pos.employee_roles = _.indexBy(roles, 'id', null);
        },
    },
]);

// To avoid false test fails
const showPopup = function checkIfInTestModeThenShowPopup(...args) {
    try {
        return Gui.showPopup(...args);
    } catch (e) {
        return Promise.resolve({confirmed: false});
    }
};

const _posmodel_super = models.PosModel.prototype;
models.PosModel = models.PosModel.extend({
    initialize: function () {
        _posmodel_super.initialize.apply(this, arguments);
        this.init_mode = true;
        this.ready.then(this.terminate_init_mode.bind(this));
    },
    terminate_init_mode: function () {
        this.init_mode = false;
    },
});

const _orderline_super = models.Orderline.prototype;
models.Orderline = models.Orderline.extend({
    initialize: function () {
        this.percentageValue = false;
        _orderline_super.initialize.apply(this, arguments);
    },
    export_as_JSON: function () {
        return {
            ..._orderline_super.export_as_JSON.apply(this, arguments),
            percentageValue: this.percentageValue,
        };
    },
    init_from_JSON: function (json) {
        if (json.percentageValue) this.percentageValue = json.percentageValue;
        return _orderline_super.init_from_JSON.apply(this, arguments);
    },
    setPercentageValue: function (pcnt) {
        this.percentageValue = pcnt;
        this.trigger('change', this);
    },
    get_price_without_tax: function () {
        // Trick for returning zero when the call stack includes
        // DiscountButton.apply_discount if needed
        const stackStr = new Error().stack;
        const calledFromDiscountButton = stackStr.includes('apply_discount');
        if (calledFromDiscountButton && !this.get_product().is_pos_discount_applicable) {
            return 0;
        }
        return _orderline_super.get_price_without_tax.apply(this, arguments);
    },
    get_tax_details: function () {
        // Trick for returning an empty Object when the call stack includes
        // DiscountButton.apply_discount if needed
        const stackStr = new Error().stack;
        const calledFromDiscountButton = stackStr.includes('apply_discount');
        if (calledFromDiscountButton && !this.get_product().is_pos_discount_applicable) {
            return {};
        }
        return _orderline_super.get_tax_details.apply(this, arguments);
    },
    set_discount: function () {
        // a pos event listener is set on ProductScreen
        // to re-render control buttons upon changing discounts
        // no need to trigger any events if the session is still initializing
        if (!this.pos.init_mode) this.pos.trigger('change:discountValue');
        return _orderline_super.set_discount.apply(this, arguments);
    },
});

const _order_super = models.Order.prototype;
models.Order = models.Order.extend({
    select_orderline: function () {
        _order_super.select_orderline.apply(this, arguments);
        this.pos.trigger('change:selectedOrderline', this.selected_orderline);
    },
    hasLineDiscount: function () {
        return this.get_orderlines()
                   .map(({discount}) => discount)
                   .some(Boolean);
    },
    getGlobalDiscountLine: function () {
        const discount_product_id = this.pos.config.discount_product_id[0];
        return this.get_orderlines().find((ol) => ol.get_product().id === discount_product_id) || false;
    },
    _validateLineDiscount: function (orderlines, cashier) {
        const lineDiscountLimit = this.pos.employee_roles[cashier.employee_role_id[0]].line_discount_limit;
        return orderlines.map(({discount}) => discount <= lineDiscountLimit).every(Boolean);
    },
    _validateGlobalDiscount: function (cashier) {
        const globalDiscountLimit = this.pos.employee_roles[cashier.employee_role_id[0]].global_discount_limit;
        const globalDiscountLine = this.getGlobalDiscountLine();
        return globalDiscountLine ? globalDiscountLine.percentageValue <= globalDiscountLimit : true;
    },
    validateDiscount: async function (cashier) {
        if (!cashier) return false;
        const orderlines = this.get_orderlines();

        // Validating line discounts
        const isLineDiscountValid = this._validateLineDiscount(orderlines, cashier);

        // Validating global discount
        const isGlobalDiscountValid = this._validateGlobalDiscount(cashier);

        // Acting upon results
        const isDiscountValid = isLineDiscountValid && isGlobalDiscountValid;

        // If discount is valid, simply return true
        if (isDiscountValid) return cashier;

        // If discount is invalid, prompt the employee to
        // choose an employee and enter their password
        // if that employee has enough access, return true
        // otherwise show an error popup and return false
        const message = this.pos.env._t(`
            Some discounts exceed ${cashier.name}'s discount limit.
            Ask your manager to enter their credentials to continue.
        `);
        const {confirmed, payload} = await showPopup('DiscountAuthPopup', {message});

        if (!confirmed) return false;

        // Checking if credentials are for a valid and if employee
        // has the rights to give such discount then recursively
        // calling the function for that employee
        const {authorized, employee} = payload || {};

        // Recursive step
        if (authorized) return await this.validateDiscount.call(this, employee); // Will eventually return a boolean

        await showPopup('ErrorPopup', {
            title: this.pos.env._t('Unauthorized'),
            body: this.pos.env._t('Wrong password'),
        });
        return false;
    },
    validateReturns: async function (cashier) {
        if (!cashier) return false;
        const orderlines = this.get_orderlines();
        const noRefundsFount = orderlines.map(ol => ol.quantity >= 0).every(Boolean);
        const canIssueRefunds = this.pos.employee_roles[cashier.employee_role_id[0]].can_issue_refunds;
        if (noRefundsFount || canIssueRefunds) return cashier;
        const message = this.pos.env._t(`
            ${cashier.name} cannot issue refunds.
            Ask your manager to enter their credentials to continue.
        `);
        const {confirmed, payload} = await showPopup('DiscountAuthPopup', {message});
        if (!confirmed) return false;
        const {authorized, employee} = payload || {};
        if (authorized) return await this.validateReturns.call(this, employee);

        await showPopup('ErrorPopup', {
            title: this.pos.env._t('Unauthorized'),
            body: this.pos.env._t('Wrong password'),
        });
        return false;
    },
});
