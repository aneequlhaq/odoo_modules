/** @odoo-module **/
import DiscountButton from "pos_discount.DiscountButton";
import ProductScreen from "point_of_sale.ProductScreen";
import Registries from "point_of_sale.Registries";

const DiscountButtonMixin = (DiscountButtonOrigin) =>
    class extends DiscountButtonOrigin {
        async apply_discount(pc) {
            const res = await super.apply_discount(...arguments);
            const globalDiscountLine = this.env.pos.get_order().getGlobalDiscountLine();
            globalDiscountLine.setPercentageValue(pc);
            return res;
        }
    };

Registries.Component.extend(DiscountButton, DiscountButtonMixin);
const discountControlButton = ProductScreen.controlButtons.find(
    (controlButton) => controlButton.name === "DiscountButton"
);
const discountControlButtonConditionSuper = discountControlButton.condition;
discountControlButton.condition = function () {
    const cashier = this.env.pos.get_cashier();
    if (!cashier || !cashier.employee_role_id) return false;
    return (
        discountControlButtonConditionSuper.call(this) &&
        this.env.pos.employee_roles[cashier.employee_role_id[0]].can_set_global_discount &&
        !this.env.pos.get_order().hasLineDiscount()
    );
};

export default DiscountButton;
